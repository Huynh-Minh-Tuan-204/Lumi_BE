import { User, Conversation, Message, Notification, LoginCredentials, ApiResponse } from './types'

// API base URL - configure for your .NET backend
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api'

// Helper to get auth headers
const getAuthHeaders = () => {
  const user = localStorage.getItem('lumi_user')
  if (user) {
    const { token } = JSON.parse(user)
    return {
      'Content-Type': 'application/json',
      Authorization: `Bearer ${token}`,
    }
  }
  return { 'Content-Type': 'application/json' }
}

// Generic fetch wrapper with error handling
async function fetchApi<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        ...getAuthHeaders(),
        ...options.headers,
      },
    })

    if (!response.ok) {
      const error = await response.text()
      return { success: false, error: error || 'Request failed' }
    }

    const data = await response.json()
    return { success: true, data }
  } catch (error) {
    return { success: false, error: 'Network error' }
  }
}

// Auth API
export const authApi = {
  login: async (credentials: LoginCredentials) =>
    fetchApi<User>('/Auth/login', {
      method: 'POST',
      body: JSON.stringify(credentials),
    }),

  me: async () => fetchApi<User>('/Auth/me'),
}

// Users API
export const usersApi = {
  getAll: async () => fetchApi<User[]>('/Users'),

  getById: async (id: string) => fetchApi<User>(`/Users/${id}`),

  create: async (user: Partial<User>) =>
    fetchApi<User>('/Users', {
      method: 'POST',
      body: JSON.stringify(user),
    }),

  update: async (id: string, user: Partial<User>) =>
    fetchApi<User>(`/Users/${id}`, {
      method: 'PUT',
      body: JSON.stringify(user),
    }),

  delete: async (id: string) =>
    fetchApi<void>(`/Users/${id}`, {
      method: 'DELETE',
    }),
}

// Conversations API
export const conversationsApi = {
  getAll: async () => fetchApi<Conversation[]>('/Conversations'),

  getById: async (id: string) => fetchApi<Conversation>(`/Conversations/${id}`),

  create: async (conversation: Partial<Conversation>) =>
    fetchApi<Conversation>('/Conversations', {
      method: 'POST',
      body: JSON.stringify(conversation),
    }),

  update: async (id: string, conversation: Partial<Conversation>) =>
    fetchApi<Conversation>(`/Conversations/${id}`, {
      method: 'PUT',
      body: JSON.stringify(conversation),
    }),

  delete: async (id: string) =>
    fetchApi<void>(`/Conversations/${id}`, {
      method: 'DELETE',
    }),

  addMember: async (conversationId: string, userId: string) =>
    fetchApi<void>(`/Conversations/${conversationId}/members`, {
      method: 'POST',
      body: JSON.stringify({ userId }),
    }),

  removeMember: async (conversationId: string, userId: string) =>
    fetchApi<void>(`/Conversations/${conversationId}/members/${userId}`, {
      method: 'DELETE',
    }),

  getMessages: async (conversationId: string, page = 1, limit = 50) =>
    fetchApi<Message[]>(`/Conversations/${conversationId}/messages?page=${page}&limit=${limit}`),
}

// Notifications API
export const notificationsApi = {
  send: async (notification: Partial<Notification>) =>
    fetchApi<void>('/notifications/send', {
      method: 'POST',
      body: JSON.stringify(notification),
    }),
}

// Export all APIs
export const api = {
  auth: authApi,
  users: usersApi,
  conversations: conversationsApi,
  notifications: notificationsApi,
}

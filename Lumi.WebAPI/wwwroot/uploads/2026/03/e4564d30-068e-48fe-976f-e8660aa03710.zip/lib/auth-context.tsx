'use client'

import { createContext, useContext, useState, useEffect, ReactNode } from 'react'
import { AuthUser, LoginCredentials, UserRole } from './types'

interface AuthContextType {
  user: AuthUser | null
  isLoading: boolean
  login: (credentials: LoginCredentials) => Promise<boolean>
  logout: () => void
  isAdmin: boolean
  isEmployee: boolean
}

const AuthContext = createContext<AuthContextType | undefined>(undefined)

// Mock users for demo - in production, this would connect to your .NET API
const MOCK_USERS: (AuthUser & { password: string })[] = [
  {
    id: '1',
    username: 'admin',
    password: 'admin123',
    email: 'admin@lumi.com',
    fullName: 'Admin User',
    role: 'Admin',
    department: 'IT',
    isOnline: true,
    createdAt: new Date().toISOString(),
    token: 'mock-admin-token',
  },
  {
    id: '2',
    username: 'employee',
    password: 'employee123',
    email: 'employee@lumi.com',
    fullName: 'John Employee',
    role: 'Employee',
    department: 'Engineering',
    isOnline: true,
    createdAt: new Date().toISOString(),
    token: 'mock-employee-token',
  },
  {
    id: '3',
    username: 'manager',
    password: 'manager123',
    email: 'manager@lumi.com',
    fullName: 'Sarah Manager',
    role: 'Manager',
    department: 'Engineering',
    isOnline: true,
    createdAt: new Date().toISOString(),
    token: 'mock-manager-token',
  },
]

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null)
  const [isLoading, setIsLoading] = useState(true)

  useEffect(() => {
    // Check for existing session
    const storedUser = localStorage.getItem('lumi_user')
    if (storedUser) {
      setUser(JSON.parse(storedUser))
    }
    setIsLoading(false)
  }, [])

  const login = async (credentials: LoginCredentials): Promise<boolean> => {
    setIsLoading(true)
    
    // Simulate API call delay
    await new Promise(resolve => setTimeout(resolve, 800))
    
    // Mock authentication - replace with actual API call
    // POST /api/Auth/login
    const foundUser = MOCK_USERS.find(
      u => u.username === credentials.username && u.password === credentials.password
    )

    if (foundUser) {
      const { password, ...userWithoutPassword } = foundUser
      setUser(userWithoutPassword)
      localStorage.setItem('lumi_user', JSON.stringify(userWithoutPassword))
      setIsLoading(false)
      return true
    }

    setIsLoading(false)
    return false
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem('lumi_user')
  }

  const isAdmin = user?.role === 'Admin'
  const isEmployee = user?.role === 'Employee' || user?.role === 'Manager'

  return (
    <AuthContext.Provider value={{ user, isLoading, login, logout, isAdmin, isEmployee }}>
      {children}
    </AuthContext.Provider>
  )
}

export function useAuth() {
  const context = useContext(AuthContext)
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider')
  }
  return context
}

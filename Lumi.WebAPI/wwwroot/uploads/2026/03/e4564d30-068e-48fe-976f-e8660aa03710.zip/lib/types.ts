export type UserRole = 'Admin' | 'Manager' | 'Employee'

export interface User {
  id: string
  username: string
  email: string
  fullName: string
  role: UserRole
  department: string
  avatar?: string
  isOnline: boolean
  lastActivity?: string
  createdAt: string
}

export interface AuthUser extends User {
  token: string
}

export interface Conversation {
  id: string
  name: string
  type: 'direct' | 'group'
  members: User[]
  lastMessage?: Message
  unreadCount: number
  createdAt: string
  updatedAt: string
}

export interface Message {
  id: string
  conversationId: string
  senderId: string
  sender: User
  content: string
  type: 'text' | 'image' | 'file'
  fileUrl?: string
  fileName?: string
  createdAt: string
  isRead: boolean
}

export interface Notification {
  id: string
  title: string
  message: string
  type: 'info' | 'success' | 'warning' | 'error'
  targetType: 'all' | 'group' | 'user'
  targetId?: string
  createdAt: string
  isRead: boolean
}

export interface Department {
  id: string
  name: string
}

export interface LoginCredentials {
  username: string
  password: string
}

export interface ApiResponse<T> {
  data?: T
  error?: string
  success: boolean
}

import { create } from 'zustand'
import { Conversation, Message } from './types'
import { MOCK_MESSAGES } from './mock-data'

interface ChatState {
  selectedConversationId: string | null
  selectedConversation: Conversation | null
  messages: Message[]
  isLoading: boolean
  setSelectedConversation: (conversation: Conversation) => void
  sendMessage: (content: string, type?: 'text' | 'image' | 'file', fileName?: string) => void
  clearSelection: () => void
}

export const useChatStore = create<ChatState>((set, get) => ({
  selectedConversationId: null,
  selectedConversation: null,
  messages: [],
  isLoading: false,

  setSelectedConversation: (conversation: Conversation) => {
    // Filter messages for this conversation
    const conversationMessages = MOCK_MESSAGES.filter(
      (m) => m.conversationId === conversation.id
    )
    set({
      selectedConversationId: conversation.id,
      selectedConversation: conversation,
      messages: conversationMessages,
    })
  },

  sendMessage: (content: string, type = 'text', fileName?: string) => {
    const { selectedConversation, messages } = get()
    if (!selectedConversation) return

    // Create new message (mock - in production would go through SignalR)
    const newMessage: Message = {
      id: String(Date.now()),
      conversationId: selectedConversation.id,
      senderId: '2', // Current user ID (mock)
      sender: {
        id: '2',
        username: 'employee',
        email: 'employee@lumi.com',
        fullName: 'John Employee',
        role: 'Employee',
        department: 'Engineering',
        isOnline: true,
        createdAt: new Date().toISOString(),
      },
      content,
      type,
      fileName,
      createdAt: new Date().toISOString(),
      isRead: true,
    }

    set({ messages: [...messages, newMessage] })
  },

  clearSelection: () => {
    set({
      selectedConversationId: null,
      selectedConversation: null,
      messages: [],
    })
  },
}))

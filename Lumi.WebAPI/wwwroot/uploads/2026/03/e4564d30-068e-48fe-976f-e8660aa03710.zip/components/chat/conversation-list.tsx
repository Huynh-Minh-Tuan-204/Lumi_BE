'use client'

import { useState } from 'react'
import { Conversation } from '@/lib/types'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Search, MessageSquare, Hash } from 'lucide-react'
import { cn } from '@/lib/utils'
import { useChatStore } from '@/lib/chat-store'

interface ConversationListProps {
  conversations: Conversation[]
}

export function ConversationList({ conversations }: ConversationListProps) {
  const [searchQuery, setSearchQuery] = useState('')
  const { selectedConversationId, setSelectedConversation } = useChatStore()

  const filteredConversations = conversations.filter((conv) =>
    conv.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const formatTime = (dateString?: string) => {
    if (!dateString) return ''
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'now'
    if (diffMins < 60) return `${diffMins}m`
    if (diffHours < 24) return `${diffHours}h`
    if (diffDays < 7) return `${diffDays}d`
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  return (
    <div className="flex flex-col h-full">
      {/* Search */}
      <div className="p-4">
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder="Search conversations..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9 bg-sidebar-accent border-0 text-sidebar-foreground placeholder:text-muted-foreground"
          />
        </div>
      </div>

      {/* Conversation List */}
      <div className="flex-1 overflow-y-auto px-2 space-y-1">
        {filteredConversations.map((conversation) => (
          <button
            key={conversation.id}
            onClick={() => setSelectedConversation(conversation)}
            className={cn(
              'w-full flex items-center gap-3 p-3 rounded-lg text-left transition-colors',
              selectedConversationId === conversation.id
                ? 'bg-sidebar-primary text-sidebar-primary-foreground'
                : 'text-sidebar-foreground hover:bg-sidebar-accent'
            )}
          >
            {/* Avatar */}
            <div className="relative flex-shrink-0">
              <div
                className={cn(
                  'w-10 h-10 rounded-lg flex items-center justify-center',
                  selectedConversationId === conversation.id
                    ? 'bg-sidebar-primary-foreground/20'
                    : 'bg-sidebar-accent'
                )}
              >
                {conversation.type === 'group' ? (
                  <Hash className="w-5 h-5" />
                ) : (
                  <span className="text-sm font-medium">
                    {conversation.name.charAt(0)}
                  </span>
                )}
              </div>
            </div>

            {/* Content */}
            <div className="flex-1 min-w-0">
              <div className="flex items-center justify-between gap-2">
                <span className="font-medium truncate">{conversation.name}</span>
                <span
                  className={cn(
                    'text-xs flex-shrink-0',
                    selectedConversationId === conversation.id
                      ? 'text-sidebar-primary-foreground/70'
                      : 'text-muted-foreground'
                  )}
                >
                  {formatTime(conversation.lastMessage?.createdAt)}
                </span>
              </div>
              <div className="flex items-center justify-between gap-2">
                <p
                  className={cn(
                    'text-sm truncate',
                    selectedConversationId === conversation.id
                      ? 'text-sidebar-primary-foreground/80'
                      : 'text-muted-foreground'
                  )}
                >
                  {conversation.lastMessage
                    ? `${conversation.lastMessage.sender.fullName.split(' ')[0]}: ${conversation.lastMessage.content}`
                    : 'No messages yet'}
                </p>
                {conversation.unreadCount > 0 && (
                  <Badge
                    variant="default"
                    className={cn(
                      'h-5 min-w-5 px-1.5 flex items-center justify-center',
                      selectedConversationId === conversation.id
                        ? 'bg-sidebar-primary-foreground text-sidebar-primary'
                        : ''
                    )}
                  >
                    {conversation.unreadCount}
                  </Badge>
                )}
              </div>
            </div>
          </button>
        ))}

        {filteredConversations.length === 0 && (
          <div className="text-center py-8">
            <MessageSquare className="w-8 h-8 mx-auto text-muted-foreground mb-2" />
            <p className="text-sm text-muted-foreground">No conversations found</p>
          </div>
        )}
      </div>
    </div>
  )
}

'use client'

import { useState, useRef, useEffect } from 'react'
import { useChatStore } from '@/lib/chat-store'
import { useAuth } from '@/lib/auth-context'
import { Message } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  Send,
  Paperclip,
  Smile,
  Phone,
  Video,
  MoreVertical,
  Users,
  FileText,
  Image as ImageIcon,
  Hash,
} from 'lucide-react'
import { cn } from '@/lib/utils'

export function ChatArea() {
  const { selectedConversation, messages, sendMessage } = useChatStore()
  const { user } = useAuth()
  const [messageInput, setMessageInput] = useState('')
  const messagesEndRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' })
  }, [messages])

  const handleSendMessage = (e: React.FormEvent) => {
    e.preventDefault()
    if (!messageInput.trim()) return
    sendMessage(messageInput.trim())
    setMessageInput('')
  }

  const formatTime = (dateString: string) => {
    return new Date(dateString).toLocaleTimeString('en-US', {
      hour: 'numeric',
      minute: '2-digit',
      hour12: true,
    })
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const today = new Date()
    const yesterday = new Date(today)
    yesterday.setDate(yesterday.getDate() - 1)

    if (date.toDateString() === today.toDateString()) {
      return 'Today'
    } else if (date.toDateString() === yesterday.toDateString()) {
      return 'Yesterday'
    }
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      month: 'long',
      day: 'numeric',
    })
  }

  const groupMessagesByDate = (msgs: Message[]) => {
    const groups: { [key: string]: Message[] } = {}
    msgs.forEach((msg) => {
      const date = new Date(msg.createdAt).toDateString()
      if (!groups[date]) {
        groups[date] = []
      }
      groups[date].push(msg)
    })
    return groups
  }

  if (!selectedConversation) {
    return (
      <div className="flex-1 flex items-center justify-center bg-background">
        <div className="text-center">
          <div className="w-16 h-16 mx-auto rounded-2xl bg-secondary flex items-center justify-center mb-4">
            <Hash className="w-8 h-8 text-muted-foreground" />
          </div>
          <h2 className="text-xl font-semibold text-foreground mb-2">
            Welcome to Lumi Chat
          </h2>
          <p className="text-muted-foreground max-w-md">
            Select a conversation from the sidebar to start messaging with your team.
          </p>
        </div>
      </div>
    )
  }

  const groupedMessages = groupMessagesByDate(messages)

  return (
    <div className="flex-1 flex flex-col bg-background">
      {/* Chat Header */}
      <header className="h-16 flex items-center justify-between px-4 md:px-6 border-b border-border bg-card">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
            <Hash className="w-5 h-5 text-primary" />
          </div>
          <div>
            <h2 className="font-semibold text-card-foreground">
              {selectedConversation.name}
            </h2>
            <p className="text-xs text-muted-foreground flex items-center gap-1">
              <Users className="w-3 h-3" />
              {selectedConversation.members.length} members
            </p>
          </div>
        </div>

        <div className="flex items-center gap-2">
          <Button variant="ghost" size="icon" className="hidden sm:flex">
            <Phone className="w-5 h-5 text-muted-foreground" />
          </Button>
          <Button variant="ghost" size="icon" className="hidden sm:flex">
            <Video className="w-5 h-5 text-muted-foreground" />
          </Button>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="icon">
                <MoreVertical className="w-5 h-5 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-popover border-border">
              <DropdownMenuItem className="text-popover-foreground">
                <Users className="w-4 h-4 mr-2" />
                View Members
              </DropdownMenuItem>
              <DropdownMenuItem className="text-popover-foreground">
                <Phone className="w-4 h-4 mr-2" />
                Start Call
              </DropdownMenuItem>
              <DropdownMenuItem className="text-popover-foreground">
                <Video className="w-4 h-4 mr-2" />
                Start Video Call
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </header>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6">
        {Object.entries(groupedMessages).map(([date, msgs]) => (
          <div key={date}>
            {/* Date Separator */}
            <div className="flex items-center gap-4 my-6">
              <div className="flex-1 h-px bg-border" />
              <span className="text-xs text-muted-foreground px-2">
                {formatDate(msgs[0].createdAt)}
              </span>
              <div className="flex-1 h-px bg-border" />
            </div>

            {/* Messages */}
            <div className="space-y-4">
              {msgs.map((message, index) => {
                const isCurrentUser = message.senderId === user?.id || message.senderId === '2'
                const showAvatar =
                  index === 0 || msgs[index - 1]?.senderId !== message.senderId

                return (
                  <div
                    key={message.id}
                    className={cn(
                      'flex gap-3',
                      isCurrentUser ? 'flex-row-reverse' : 'flex-row'
                    )}
                  >
                    {/* Avatar */}
                    {showAvatar ? (
                      <div className="w-8 h-8 rounded-full bg-secondary flex-shrink-0 flex items-center justify-center">
                        <span className="text-xs font-medium text-secondary-foreground">
                          {message.sender.fullName.charAt(0)}
                        </span>
                      </div>
                    ) : (
                      <div className="w-8 flex-shrink-0" />
                    )}

                    {/* Message Content */}
                    <div
                      className={cn(
                        'max-w-[70%] space-y-1',
                        isCurrentUser ? 'items-end' : 'items-start'
                      )}
                    >
                      {showAvatar && (
                        <div
                          className={cn(
                            'flex items-center gap-2',
                            isCurrentUser ? 'flex-row-reverse' : 'flex-row'
                          )}
                        >
                          <span className="text-sm font-medium text-foreground">
                            {isCurrentUser ? 'You' : message.sender.fullName}
                          </span>
                          <span className="text-xs text-muted-foreground">
                            {formatTime(message.createdAt)}
                          </span>
                        </div>
                      )}

                      <div
                        className={cn(
                          'rounded-2xl px-4 py-2',
                          isCurrentUser
                            ? 'bg-primary text-primary-foreground rounded-tr-md'
                            : 'bg-secondary text-secondary-foreground rounded-tl-md'
                        )}
                      >
                        {message.type === 'file' ? (
                          <div className="flex items-center gap-2">
                            <FileText className="w-4 h-4" />
                            <span className="text-sm">{message.fileName}</span>
                          </div>
                        ) : message.type === 'image' ? (
                          <div className="flex items-center gap-2">
                            <ImageIcon className="w-4 h-4" />
                            <span className="text-sm">Image</span>
                          </div>
                        ) : (
                          <p className="text-sm whitespace-pre-wrap">{message.content}</p>
                        )}
                      </div>
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>

      {/* Message Input */}
      <div className="p-4 border-t border-border bg-card">
        <form onSubmit={handleSendMessage} className="flex items-center gap-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button type="button" variant="ghost" size="icon">
                <Paperclip className="w-5 h-5 text-muted-foreground" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent className="bg-popover border-border">
              <DropdownMenuItem className="text-popover-foreground">
                <ImageIcon className="w-4 h-4 mr-2" />
                Upload Image
              </DropdownMenuItem>
              <DropdownMenuItem className="text-popover-foreground">
                <FileText className="w-4 h-4 mr-2" />
                Upload File
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <Input
            value={messageInput}
            onChange={(e) => setMessageInput(e.target.value)}
            placeholder="Type a message..."
            className="flex-1 bg-input border-border"
          />

          <Button type="button" variant="ghost" size="icon">
            <Smile className="w-5 h-5 text-muted-foreground" />
          </Button>

          <Button
            type="submit"
            size="icon"
            disabled={!messageInput.trim()}
            className="bg-primary text-primary-foreground hover:bg-primary/90"
          >
            <Send className="w-4 h-4" />
          </Button>
        </form>
      </div>
    </div>
  )
}

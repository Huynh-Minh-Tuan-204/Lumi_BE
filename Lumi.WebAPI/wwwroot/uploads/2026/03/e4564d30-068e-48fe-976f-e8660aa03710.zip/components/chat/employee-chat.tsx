'use client'

import { ChatArea } from './chat-area'

export function EmployeeChat() {
  return <ChatArea />
}

'use client'

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Users, MessageSquare, UserCheck, Bell, TrendingUp, Activity } from 'lucide-react'

const stats = [
  {
    title: 'Total Users',
    value: '248',
    change: '+12%',
    icon: Users,
    description: 'Active employees',
  },
  {
    title: 'Chat Groups',
    value: '32',
    change: '+4',
    icon: MessageSquare,
    description: 'Active conversations',
  },
  {
    title: 'Online Now',
    value: '127',
    change: '+8%',
    icon: UserCheck,
    description: 'Currently active',
  },
  {
    title: 'Notifications Sent',
    value: '1,284',
    change: '+23%',
    icon: Bell,
    description: 'This month',
  },
]

const recentActivity = [
  { user: 'Sarah Johnson', action: 'joined', target: 'Engineering Team', time: '2 min ago' },
  { user: 'Mike Chen', action: 'created', target: 'Q1 Planning', time: '15 min ago' },
  { user: 'Emily Davis', action: 'sent notification to', target: 'All Users', time: '1 hour ago' },
  { user: 'Alex Wilson', action: 'updated', target: 'Marketing Group', time: '2 hours ago' },
  { user: 'Chris Brown', action: 'removed', target: 'Inactive User', time: '3 hours ago' },
]

const onlineUsers = [
  { name: 'Sarah Johnson', department: 'Engineering', status: 'Active' },
  { name: 'Mike Chen', department: 'Design', status: 'In meeting' },
  { name: 'Emily Davis', department: 'HR', status: 'Active' },
  { name: 'Alex Wilson', department: 'Marketing', status: 'Away' },
]

export function AdminDashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Dashboard</h1>
        <p className="text-muted-foreground">Welcome back! Here&apos;s what&apos;s happening.</p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="bg-card border-border">
            <CardHeader className="flex flex-row items-center justify-between pb-2">
              <CardTitle className="text-sm font-medium text-muted-foreground">
                {stat.title}
              </CardTitle>
              <stat.icon className="w-4 h-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold text-card-foreground">{stat.value}</div>
              <div className="flex items-center gap-1 text-xs">
                <span className="text-primary flex items-center">
                  <TrendingUp className="w-3 h-3 mr-1" />
                  {stat.change}
                </span>
                <span className="text-muted-foreground">{stat.description}</span>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      <div className="grid gap-6 lg:grid-cols-2">
        {/* Recent Activity */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <Activity className="w-5 h-5 text-primary" />
              Recent Activity
            </CardTitle>
            <CardDescription>Latest actions in the system</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentActivity.map((activity, index) => (
                <div key={index} className="flex items-start gap-3">
                  <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center flex-shrink-0">
                    <span className="text-xs font-medium text-secondary-foreground">
                      {activity.user.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-card-foreground">
                      <span className="font-medium">{activity.user}</span>{' '}
                      <span className="text-muted-foreground">{activity.action}</span>{' '}
                      <span className="font-medium text-primary">{activity.target}</span>
                    </p>
                    <p className="text-xs text-muted-foreground">{activity.time}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Online Users */}
        <Card className="bg-card border-border">
          <CardHeader>
            <CardTitle className="flex items-center gap-2 text-card-foreground">
              <UserCheck className="w-5 h-5 text-primary" />
              Online Now
            </CardTitle>
            <CardDescription>Currently active team members</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {onlineUsers.map((user, index) => (
                <div key={index} className="flex items-center justify-between">
                  <div className="flex items-center gap-3">
                    <div className="relative">
                      <div className="w-8 h-8 rounded-full bg-secondary flex items-center justify-center">
                        <span className="text-xs font-medium text-secondary-foreground">
                          {user.name.charAt(0)}
                        </span>
                      </div>
                      <span className="absolute bottom-0 right-0 w-2.5 h-2.5 bg-primary rounded-full border-2 border-card" />
                    </div>
                    <div>
                      <p className="text-sm font-medium text-card-foreground">{user.name}</p>
                      <p className="text-xs text-muted-foreground">{user.department}</p>
                    </div>
                  </div>
                  <span className={`text-xs px-2 py-1 rounded-full ${
                    user.status === 'Active' 
                      ? 'bg-primary/20 text-primary' 
                      : user.status === 'Away' 
                        ? 'bg-yellow-500/20 text-yellow-400'
                        : 'bg-secondary text-secondary-foreground'
                  }`}>
                    {user.status}
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}

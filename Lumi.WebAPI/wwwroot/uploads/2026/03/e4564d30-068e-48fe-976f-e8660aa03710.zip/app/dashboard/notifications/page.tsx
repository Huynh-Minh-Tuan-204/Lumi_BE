'use client'

import { useState } from 'react'
import { MOCK_NOTIFICATIONS, MOCK_CONVERSATIONS } from '@/lib/mock-data'
import { Notification } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Bell,
  Send,
  Plus,
  Info,
  CheckCircle2,
  AlertTriangle,
  AlertCircle,
  Users,
  Globe,
} from 'lucide-react'

type NotificationType = 'info' | 'success' | 'warning' | 'error'

export default function NotificationsPage() {
  const [notifications, setNotifications] = useState<Notification[]>(MOCK_NOTIFICATIONS)
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [formData, setFormData] = useState({
    title: '',
    message: '',
    type: 'info' as NotificationType,
    targetType: 'all' as 'all' | 'group',
    targetId: '',
  })

  const handleSendNotification = () => {
    const newNotification: Notification = {
      id: String(Date.now()),
      ...formData,
      createdAt: new Date().toISOString(),
      isRead: false,
    }
    setNotifications([newNotification, ...notifications])
    setIsCreateDialogOpen(false)
    resetForm()
  }

  const resetForm = () => {
    setFormData({
      title: '',
      message: '',
      type: 'info',
      targetType: 'all',
      targetId: '',
    })
  }

  const getTypeIcon = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return <CheckCircle2 className="w-5 h-5 text-primary" />
      case 'warning':
        return <AlertTriangle className="w-5 h-5 text-yellow-500" />
      case 'error':
        return <AlertCircle className="w-5 h-5 text-destructive" />
      default:
        return <Info className="w-5 h-5 text-blue-400" />
    }
  }

  const getTypeBadge = (type: NotificationType) => {
    switch (type) {
      case 'success':
        return <Badge className="bg-primary/20 text-primary border-0">Success</Badge>
      case 'warning':
        return <Badge className="bg-yellow-500/20 text-yellow-500 border-0">Warning</Badge>
      case 'error':
        return <Badge className="bg-destructive/20 text-destructive border-0">Error</Badge>
      default:
        return <Badge className="bg-blue-500/20 text-blue-400 border-0">Info</Badge>
    }
  }

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffHours < 1) return 'Just now'
    if (diffHours < 24) return `${diffHours}h ago`
    if (diffDays < 7) return `${diffDays}d ago`
    return date.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })
  }

  const getTargetLabel = (notification: Notification) => {
    if (notification.targetType === 'all') {
      return (
        <span className="flex items-center gap-1 text-xs text-muted-foreground">
          <Globe className="w-3 h-3" /> All Users
        </span>
      )
    }
    const group = MOCK_CONVERSATIONS.find((c) => c.id === notification.targetId)
    return (
      <span className="flex items-center gap-1 text-xs text-muted-foreground">
        <Users className="w-3 h-3" /> {group?.name || 'Group'}
      </span>
    )
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Notifications</h1>
          <p className="text-muted-foreground">Send announcements to your team</p>
        </div>
        <Button
          onClick={() => setIsCreateDialogOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Send className="w-4 h-4 mr-2" />
          Send Notification
        </Button>
      </div>

      {/* Quick Actions */}
      <div className="grid gap-4 md:grid-cols-2">
        <Card
          className="bg-card border-border cursor-pointer hover:bg-secondary/30 transition-colors"
          onClick={() => {
            setFormData({ ...formData, targetType: 'all' })
            setIsCreateDialogOpen(true)
          }}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <Globe className="w-6 h-6 text-primary" />
              </div>
              <div>
                <h3 className="font-medium text-card-foreground">Notify All Users</h3>
                <p className="text-sm text-muted-foreground">
                  Send a broadcast to everyone
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card
          className="bg-card border-border cursor-pointer hover:bg-secondary/30 transition-colors"
          onClick={() => {
            setFormData({ ...formData, targetType: 'group' })
            setIsCreateDialogOpen(true)
          }}
        >
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-secondary flex items-center justify-center">
                <Users className="w-6 h-6 text-secondary-foreground" />
              </div>
              <div>
                <h3 className="font-medium text-card-foreground">Notify Group</h3>
                <p className="text-sm text-muted-foreground">
                  Send to a specific team
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Notification History */}
      <Card className="bg-card border-border">
        <CardHeader>
          <CardTitle className="flex items-center gap-2 text-card-foreground">
            <Bell className="w-5 h-5 text-primary" />
            Notification History
          </CardTitle>
          <CardDescription>Recent notifications sent to your organization</CardDescription>
        </CardHeader>
        <CardContent>
          {notifications.length > 0 ? (
            <div className="space-y-4">
              {notifications.map((notification) => (
                <div
                  key={notification.id}
                  className="flex items-start gap-4 p-4 rounded-lg bg-secondary/30"
                >
                  <div className="mt-0.5">{getTypeIcon(notification.type)}</div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 mb-1">
                      <h3 className="font-medium text-card-foreground">{notification.title}</h3>
                      {getTypeBadge(notification.type)}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">{notification.message}</p>
                    <div className="flex items-center gap-4">
                      {getTargetLabel(notification)}
                      <span className="text-xs text-muted-foreground">
                        {formatDate(notification.createdAt)}
                      </span>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-12">
              <Bell className="w-12 h-12 mx-auto text-muted-foreground mb-4" />
              <p className="text-muted-foreground">No notifications sent yet</p>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Create Notification Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Send Notification</DialogTitle>
            <DialogDescription>
              Compose and send a notification to your team
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-card-foreground">Title</Label>
              <Input
                value={formData.title}
                onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                placeholder="Notification title"
                className="bg-input border-border"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-card-foreground">Message</Label>
              <Textarea
                value={formData.message}
                onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                placeholder="Write your notification message..."
                className="bg-input border-border min-h-24"
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label className="text-card-foreground">Type</Label>
                <Select
                  value={formData.type}
                  onValueChange={(value: NotificationType) =>
                    setFormData({ ...formData, type: value })
                  }
                >
                  <SelectTrigger className="bg-input border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="info">Info</SelectItem>
                    <SelectItem value="success">Success</SelectItem>
                    <SelectItem value="warning">Warning</SelectItem>
                    <SelectItem value="error">Error</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label className="text-card-foreground">Target</Label>
                <Select
                  value={formData.targetType}
                  onValueChange={(value: 'all' | 'group') =>
                    setFormData({ ...formData, targetType: value, targetId: '' })
                  }
                >
                  <SelectTrigger className="bg-input border-border">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all">All Users</SelectItem>
                    <SelectItem value="group">Specific Group</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            {formData.targetType === 'group' && (
              <div className="space-y-2">
                <Label className="text-card-foreground">Select Group</Label>
                <Select
                  value={formData.targetId}
                  onValueChange={(value) => setFormData({ ...formData, targetId: value })}
                >
                  <SelectTrigger className="bg-input border-border">
                    <SelectValue placeholder="Choose a group" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    {MOCK_CONVERSATIONS.map((group) => (
                      <SelectItem key={group.id} value={group.id}>
                        {group.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleSendNotification}
              disabled={!formData.title || !formData.message}
              className="bg-primary text-primary-foreground"
            >
              <Send className="w-4 h-4 mr-2" />
              Send Notification
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

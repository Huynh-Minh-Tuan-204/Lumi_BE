'use client'

import { useAuth } from '@/lib/auth-context'
import { AdminDashboard } from '@/components/admin/admin-dashboard'
import { EmployeeChat } from '@/components/chat/employee-chat'

export default function DashboardPage() {
  const { isAdmin } = useAuth()

  if (isAdmin) {
    return <AdminDashboard />
  }

  return <EmployeeChat />
}

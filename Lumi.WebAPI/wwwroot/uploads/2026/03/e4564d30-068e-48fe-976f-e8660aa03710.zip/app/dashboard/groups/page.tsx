'use client'

import { useState } from 'react'
import { MOCK_CONVERSATIONS, MOCK_USERS } from '@/lib/mock-data'
import { Conversation, User } from '@/lib/types'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Badge } from '@/components/ui/badge'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Checkbox } from '@/components/ui/checkbox'
import {
  Plus,
  Search,
  MoreHorizontal,
  Pencil,
  Trash2,
  Users,
  MessageSquare,
  UserPlus,
  UserMinus,
} from 'lucide-react'

export default function GroupsPage() {
  const [groups, setGroups] = useState<Conversation[]>(MOCK_CONVERSATIONS)
  const [searchQuery, setSearchQuery] = useState('')
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [isDeleteDialogOpen, setIsDeleteDialogOpen] = useState(false)
  const [isMembersDialogOpen, setIsMembersDialogOpen] = useState(false)
  const [selectedGroup, setSelectedGroup] = useState<Conversation | null>(null)
  const [groupName, setGroupName] = useState('')
  const [selectedMembers, setSelectedMembers] = useState<string[]>([])

  const filteredGroups = groups.filter((group) =>
    group.name.toLowerCase().includes(searchQuery.toLowerCase())
  )

  const handleCreateGroup = () => {
    const selectedUsers = MOCK_USERS.filter((u) => selectedMembers.includes(u.id))
    const newGroup: Conversation = {
      id: String(Date.now()),
      name: groupName,
      type: 'group',
      members: selectedUsers,
      unreadCount: 0,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }
    setGroups([...groups, newGroup])
    setIsCreateDialogOpen(false)
    resetForm()
  }

  const handleEditGroup = () => {
    if (!selectedGroup) return
    setGroups(
      groups.map((group) =>
        group.id === selectedGroup.id ? { ...group, name: groupName } : group
      )
    )
    setIsEditDialogOpen(false)
    setSelectedGroup(null)
    resetForm()
  }

  const handleDeleteGroup = () => {
    if (!selectedGroup) return
    setGroups(groups.filter((group) => group.id !== selectedGroup.id))
    setIsDeleteDialogOpen(false)
    setSelectedGroup(null)
  }

  const handleUpdateMembers = () => {
    if (!selectedGroup) return
    const selectedUsers = MOCK_USERS.filter((u) => selectedMembers.includes(u.id))
    setGroups(
      groups.map((group) =>
        group.id === selectedGroup.id ? { ...group, members: selectedUsers } : group
      )
    )
    setIsMembersDialogOpen(false)
    setSelectedGroup(null)
    setSelectedMembers([])
  }

  const openEditDialog = (group: Conversation) => {
    setSelectedGroup(group)
    setGroupName(group.name)
    setIsEditDialogOpen(true)
  }

  const openDeleteDialog = (group: Conversation) => {
    setSelectedGroup(group)
    setIsDeleteDialogOpen(true)
  }

  const openMembersDialog = (group: Conversation) => {
    setSelectedGroup(group)
    setSelectedMembers(group.members.map((m) => m.id))
    setIsMembersDialogOpen(true)
  }

  const resetForm = () => {
    setGroupName('')
    setSelectedMembers([])
  }

  const toggleMember = (userId: string) => {
    setSelectedMembers((prev) =>
      prev.includes(userId)
        ? prev.filter((id) => id !== userId)
        : [...prev, userId]
    )
  }

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      month: 'short',
      day: 'numeric',
      year: 'numeric',
    })
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Chat Groups</h1>
          <p className="text-muted-foreground">Manage conversation groups</p>
        </div>
        <Button
          onClick={() => setIsCreateDialogOpen(true)}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          <Plus className="w-4 h-4 mr-2" />
          Create Group
        </Button>
      </div>

      {/* Search */}
      <Card className="bg-card border-border">
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search groups..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-input border-border"
            />
          </div>
        </CardContent>
      </Card>

      {/* Groups Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {filteredGroups.map((group) => (
          <Card key={group.id} className="bg-card border-border">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-primary/20 flex items-center justify-center">
                    <MessageSquare className="w-5 h-5 text-primary" />
                  </div>
                  <div>
                    <CardTitle className="text-base text-card-foreground">{group.name}</CardTitle>
                    <CardDescription className="flex items-center gap-1">
                      <Users className="w-3 h-3" />
                      {group.members.length} members
                    </CardDescription>
                  </div>
                </div>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="icon" className="h-8 w-8">
                      <MoreHorizontal className="w-4 h-4" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="bg-popover border-border">
                    <DropdownMenuItem
                      onClick={() => openEditDialog(group)}
                      className="text-popover-foreground"
                    >
                      <Pencil className="w-4 h-4 mr-2" />
                      Edit Name
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => openMembersDialog(group)}
                      className="text-popover-foreground"
                    >
                      <UserPlus className="w-4 h-4 mr-2" />
                      Manage Members
                    </DropdownMenuItem>
                    <DropdownMenuItem
                      onClick={() => openDeleteDialog(group)}
                      className="text-destructive"
                    >
                      <Trash2 className="w-4 h-4 mr-2" />
                      Delete Group
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {/* Members Preview */}
                <div className="flex -space-x-2">
                  {group.members.slice(0, 5).map((member) => (
                    <div
                      key={member.id}
                      className="w-7 h-7 rounded-full bg-secondary border-2 border-card flex items-center justify-center"
                      title={member.fullName}
                    >
                      <span className="text-xs font-medium text-secondary-foreground">
                        {member.fullName.charAt(0)}
                      </span>
                    </div>
                  ))}
                  {group.members.length > 5 && (
                    <div className="w-7 h-7 rounded-full bg-muted border-2 border-card flex items-center justify-center">
                      <span className="text-xs font-medium text-muted-foreground">
                        +{group.members.length - 5}
                      </span>
                    </div>
                  )}
                </div>

                {/* Last Activity */}
                <div className="flex items-center justify-between text-xs text-muted-foreground">
                  <span>Created {formatDate(group.createdAt)}</span>
                  {group.unreadCount > 0 && (
                    <Badge variant="default" className="h-5 px-2">
                      {group.unreadCount} new
                    </Badge>
                  )}
                </div>

                {/* Last Message Preview */}
                {group.lastMessage && (
                  <p className="text-sm text-muted-foreground truncate">
                    <span className="font-medium text-card-foreground">
                      {group.lastMessage.sender.fullName.split(' ')[0]}:
                    </span>{' '}
                    {group.lastMessage.content}
                  </p>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Create Group Dialog */}
      <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Create New Group</DialogTitle>
            <DialogDescription>Create a new chat group for your team</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-card-foreground">Group Name</Label>
              <Input
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                placeholder="Enter group name"
                className="bg-input border-border"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-card-foreground">Select Members</Label>
              <div className="max-h-48 overflow-y-auto space-y-2 p-2 rounded-lg bg-secondary/30">
                {MOCK_USERS.map((user) => (
                  <div
                    key={user.id}
                    className="flex items-center gap-3 p-2 rounded hover:bg-secondary/50 cursor-pointer"
                    onClick={() => toggleMember(user.id)}
                  >
                    <Checkbox
                      checked={selectedMembers.includes(user.id)}
                      onCheckedChange={() => toggleMember(user.id)}
                    />
                    <div className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center">
                      <span className="text-xs font-medium text-secondary-foreground">
                        {user.fullName.charAt(0)}
                      </span>
                    </div>
                    <div className="flex-1">
                      <p className="text-sm font-medium text-card-foreground">{user.fullName}</p>
                      <p className="text-xs text-muted-foreground">{user.department}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
              Cancel
            </Button>
            <Button
              onClick={handleCreateGroup}
              disabled={!groupName || selectedMembers.length === 0}
              className="bg-primary text-primary-foreground"
            >
              <Plus className="w-4 h-4 mr-2" />
              Create Group
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Edit Group Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Edit Group Name</DialogTitle>
            <DialogDescription>Update the group name</DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="space-y-2">
              <Label className="text-card-foreground">Group Name</Label>
              <Input
                value={groupName}
                onChange={(e) => setGroupName(e.target.value)}
                className="bg-input border-border"
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleEditGroup} className="bg-primary text-primary-foreground">
              Save Changes
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Manage Members Dialog */}
      <Dialog open={isMembersDialogOpen} onOpenChange={setIsMembersDialogOpen}>
        <DialogContent className="bg-card border-border max-w-md">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Manage Members</DialogTitle>
            <DialogDescription>
              Add or remove members from {selectedGroup?.name}
            </DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <div className="max-h-64 overflow-y-auto space-y-2 p-2 rounded-lg bg-secondary/30">
              {MOCK_USERS.map((user) => (
                <div
                  key={user.id}
                  className="flex items-center gap-3 p-2 rounded hover:bg-secondary/50 cursor-pointer"
                  onClick={() => toggleMember(user.id)}
                >
                  <Checkbox
                    checked={selectedMembers.includes(user.id)}
                    onCheckedChange={() => toggleMember(user.id)}
                  />
                  <div className="w-7 h-7 rounded-full bg-secondary flex items-center justify-center">
                    <span className="text-xs font-medium text-secondary-foreground">
                      {user.fullName.charAt(0)}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="text-sm font-medium text-card-foreground">{user.fullName}</p>
                    <p className="text-xs text-muted-foreground">{user.department}</p>
                  </div>
                  {selectedMembers.includes(user.id) && (
                    <Badge variant="outline" className="text-xs">
                      Member
                    </Badge>
                  )}
                </div>
              ))}
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsMembersDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={handleUpdateMembers} className="bg-primary text-primary-foreground">
              <Users className="w-4 h-4 mr-2" />
              Update Members
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation Dialog */}
      <Dialog open={isDeleteDialogOpen} onOpenChange={setIsDeleteDialogOpen}>
        <DialogContent className="bg-card border-border">
          <DialogHeader>
            <DialogTitle className="text-card-foreground">Delete Group</DialogTitle>
            <DialogDescription>
              Are you sure you want to delete &quot;{selectedGroup?.name}&quot;? This will remove all messages and cannot be undone.
            </DialogDescription>
          </DialogHeader>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsDeleteDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleDeleteGroup}>
              <Trash2 className="w-4 h-4 mr-2" />
              Delete Group
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}

'use client'

import { useState } from 'react'
import { MOCK_USERS } from '@/lib/mock-data'
import { User } from '@/lib/types'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Search, UserCheck, Clock, Circle } from 'lucide-react'

export default function OnlinePage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [activeTab, setActiveTab] = useState('online')

  const onlineUsers = MOCK_USERS.filter((user) => user.isOnline)
  const offlineUsers = MOCK_USERS.filter((user) => !user.isOnline)

  const filterUsers = (users: User[]) => {
    return users.filter(
      (user) =>
        user.fullName.toLowerCase().includes(searchQuery.toLowerCase()) ||
        user.department.toLowerCase().includes(searchQuery.toLowerCase())
    )
  }

  const formatLastActivity = (dateString?: string) => {
    if (!dateString) return 'Unknown'
    const date = new Date(dateString)
    const now = new Date()
    const diffMs = now.getTime() - date.getTime()
    const diffMins = Math.floor(diffMs / 60000)
    const diffHours = Math.floor(diffMs / 3600000)
    const diffDays = Math.floor(diffMs / 86400000)

    if (diffMins < 1) return 'Just now'
    if (diffMins < 60) return `${diffMins}m ago`
    if (diffHours < 24) return `${diffHours}h ago`
    return `${diffDays}d ago`
  }

  const getStatusColor = (isOnline: boolean, lastActivity?: string) => {
    if (isOnline) return 'bg-primary'
    const date = new Date(lastActivity || '')
    const diffMs = new Date().getTime() - date.getTime()
    const diffHours = Math.floor(diffMs / 3600000)
    if (diffHours < 2) return 'bg-yellow-500'
    return 'bg-muted-foreground'
  }

  const UserCard = ({ user }: { user: User }) => (
    <div className="flex items-center justify-between p-4 rounded-lg bg-secondary/30 hover:bg-secondary/50 transition-colors">
      <div className="flex items-center gap-4">
        <div className="relative">
          <div className="w-12 h-12 rounded-full bg-secondary flex items-center justify-center">
            <span className="text-lg font-medium text-secondary-foreground">
              {user.fullName.charAt(0)}
            </span>
          </div>
          <span
            className={`absolute bottom-0 right-0 w-3.5 h-3.5 rounded-full border-2 border-card ${getStatusColor(
              user.isOnline,
              user.lastActivity
            )}`}
          />
        </div>
        <div>
          <h3 className="font-medium text-card-foreground">{user.fullName}</h3>
          <p className="text-sm text-muted-foreground">{user.department}</p>
        </div>
      </div>
      <div className="flex flex-col items-end gap-1">
        <Badge variant={user.isOnline ? 'default' : 'secondary'}>
          {user.isOnline ? 'Online' : 'Offline'}
        </Badge>
        <span className="text-xs text-muted-foreground flex items-center gap-1">
          <Clock className="w-3 h-3" />
          {formatLastActivity(user.lastActivity)}
        </span>
      </div>
    </div>
  )

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold text-foreground">Online Employees</h1>
        <p className="text-muted-foreground">Monitor team availability and activity</p>
      </div>

      {/* Stats */}
      <div className="grid gap-4 md:grid-cols-3">
        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-primary/20 flex items-center justify-center">
                <UserCheck className="w-6 h-6 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold text-card-foreground">{onlineUsers.length}</p>
                <p className="text-sm text-muted-foreground">Currently Online</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-yellow-500/20 flex items-center justify-center">
                <Circle className="w-6 h-6 text-yellow-500" />
              </div>
              <div>
                <p className="text-2xl font-bold text-card-foreground">
                  {offlineUsers.filter((u) => {
                    const diffHours =
                      (new Date().getTime() - new Date(u.lastActivity || '').getTime()) / 3600000
                    return diffHours < 2
                  }).length}
                </p>
                <p className="text-sm text-muted-foreground">Recently Active</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card className="bg-card border-border">
          <CardContent className="pt-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-lg bg-muted flex items-center justify-center">
                <Circle className="w-6 h-6 text-muted-foreground" />
              </div>
              <div>
                <p className="text-2xl font-bold text-card-foreground">{offlineUsers.length}</p>
                <p className="text-sm text-muted-foreground">Offline</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Search */}
      <Card className="bg-card border-border">
        <CardContent className="pt-6">
          <div className="relative max-w-sm">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
            <Input
              placeholder="Search employees..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 bg-input border-border"
            />
          </div>
        </CardContent>
      </Card>

      {/* User Lists */}
      <Card className="bg-card border-border">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle className="text-card-foreground">Team Status</CardTitle>
                <CardDescription>View employee availability</CardDescription>
              </div>
              <TabsList className="bg-secondary">
                <TabsTrigger value="online">Online ({onlineUsers.length})</TabsTrigger>
                <TabsTrigger value="offline">Offline ({offlineUsers.length})</TabsTrigger>
                <TabsTrigger value="all">All ({MOCK_USERS.length})</TabsTrigger>
              </TabsList>
            </div>
          </CardHeader>
          <CardContent>
            <TabsContent value="online" className="mt-0 space-y-3">
              {filterUsers(onlineUsers).length > 0 ? (
                filterUsers(onlineUsers).map((user) => <UserCard key={user.id} user={user} />)
              ) : (
                <p className="text-center py-8 text-muted-foreground">No online users found</p>
              )}
            </TabsContent>
            <TabsContent value="offline" className="mt-0 space-y-3">
              {filterUsers(offlineUsers).length > 0 ? (
                filterUsers(offlineUsers).map((user) => <UserCard key={user.id} user={user} />)
              ) : (
                <p className="text-center py-8 text-muted-foreground">No offline users found</p>
              )}
            </TabsContent>
            <TabsContent value="all" className="mt-0 space-y-3">
              {filterUsers(MOCK_USERS).length > 0 ? (
                filterUsers(MOCK_USERS).map((user) => <UserCard key={user.id} user={user} />)
              ) : (
                <p className="text-center py-8 text-muted-foreground">No users found</p>
              )}
            </TabsContent>
          </CardContent>
        </Tabs>
      </Card>
    </div>
  )
}
